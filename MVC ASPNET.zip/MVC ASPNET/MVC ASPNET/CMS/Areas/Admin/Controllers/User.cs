﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using CMS.DataAccess.Data.IRepository;
using CMS.Utility;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CMS.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = SD.Admin)]
    public class UserController : Controller
    {
        private readonly IUnitofWork _unitofWork;

        public UserController(IUnitofWork unitofWork)
        {
            _unitofWork = unitofWork;
        }

        public IActionResult Index()
        {
            var claimsIdentity = (ClaimsIdentity)this.User.Identity;
            var claims = claimsIdentity.FindFirst(ClaimTypes.NameIdentifier);

            return View(_unitofWork.User.GetAll(i => i.Id != claims.Value));
        }

        public IActionResult Lock(string id)
        {
            if (id == null)
            {
                return NotFound();
            }
            _unitofWork.User.LockUser(id);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult UnLock(string id)
        {
            if (id == null)
            {
                return NotFound();
            }
            _unitofWork.User.UnLockUser(id);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult DownloadUserList()
        {
            var userList = _unitofWork.User.GetAll();
            
            // Generate the CSV file content
            string csvContent = "First Name,Last Name,Email,Phone Number\r\n";
            foreach (var user in userList)
            {
                csvContent += $"{user.FName},{user.LName},{user.Email},{user.PhoneNumber}\r\n";
            }

            // Set the response headers for file download
            byte[] csvBytes = System.Text.Encoding.UTF8.GetBytes(csvContent);
            return File(csvBytes, "text/csv", "UserList.csv");
        }
    }
}
