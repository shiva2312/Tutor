﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CMS.Utility
{
    public static class SD
    {
        public const string Admin = "Admin";
        public const string Manager = "Manager";
        public const string Employee = "Employee";
    }
}
